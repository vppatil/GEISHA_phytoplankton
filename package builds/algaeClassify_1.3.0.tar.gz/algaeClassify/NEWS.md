# algaeClassify 1.2.0

## Major changes

- package now includes ability to classify species to csr or mfg using traits
- algaebase database search functionality now available (algae_search and spp_list_algaebase)
- data aggregation functions phyto_ts_aggregate and date_mat
- species richness timeseries diagnostic plots (accum, sampeff)